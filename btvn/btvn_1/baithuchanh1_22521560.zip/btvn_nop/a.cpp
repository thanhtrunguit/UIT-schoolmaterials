
#include <iostream>
using namespace std;

int main()
{
    int year;
    cout << "put in your birth year: " << endl;
    cin >> year;
    cout << "your age is: " << 2022 - year;
}
