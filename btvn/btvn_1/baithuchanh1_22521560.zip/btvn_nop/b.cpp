#include <iostream>
using namespace std;

int main()
{
    double a;
    double b;

    //inout numbers
    cout << "put in the first number: ";
    cin >> a;
    cout << "put in the second number: ";
    cin >> b;

    //calculating processes

    cout << "sum: " << a + b << endl;
    cout << "minus: " << a-b << endl;
    cout << "multiplication: " << a*b << endl;
    cout << "divide: " << a/b << endl;
}
