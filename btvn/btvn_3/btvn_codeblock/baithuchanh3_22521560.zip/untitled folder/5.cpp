#include <iostream>
#include  <cmath>
using namespace std;
int main() {
    int n =1;


    for(n; n<=10; n++)
    {
        for(int i =1; i<=10; i++)
        {
            cout << n<< "*"<< i<< "="<<  n*i << endl;
        }
    }


}
